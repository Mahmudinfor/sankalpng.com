
<?php 
include 'db_connect.php';

?>
  <div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-envelope"></i> <a href="mailto:<?php echo isset($meta['email']) ? $meta['email'] : '' ?>"><?php echo isset($meta['email']) ? $meta['email'] : '' ?></a>
        <i class="icofont-phone"></i> <?php echo isset($meta['contact']) ? $meta['contact'] : '' ?>
      </div>
      <div class="social-links">
        <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="#" class="skype"><i class="icofont-skype"></i></a>
        <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">
      <a href="#" class="logo mr-auto"><img src="https://static.vecteezy.com/system/resources/thumbnails/014/664/545/small/oil-and-gas-logo-images-vector.jpg" srcset="https://static.vecteezy.com/system/resources/thumbnails/014/664/545/small_2x/oil-and-gas-logo-images-vector.jpg" alt="" class="img-fluid"></a>

      <h1 class="logo mr-auto"><?php echo isset($meta['blog_name']) ? $meta['blog_name'] : '' ?></h1>
                          <!--company name link back to HOME when click on it, Put the index link between the href="" at top code line-->
      <!-- Uncomment/remove= below if you prefer to use an image logo at the top  -->
      <!--<a href="#" class="logo mr-auto"><img src="https://static.vecteezy.com/system/resources/thumbnails/014/664/545/small/oil-and-gas-logo-images-vector.jpg" srcset="https://static.vecteezy.com/system/resources/thumbnails/014/664/545/small_2x/oil-and-gas-logo-images-vector.jpg" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="nav-home"><a href="index.php?page=home">Home</a></li>
          <li class="drop-down"><a href="javascript:void(0)">Category</a>
            <ul>
              <?php
              $qry = $conn->query("SELECT * from category where status = 1"); 
            while($row=$qry->fetch_assoc()){
               ?>
                <li><a href="index.php?page=category&id=<?php echo $row['id'] ?>"><?php echo $row['name'] ?></a></li>
              <?php } ?>
            </ul>
          </li>
          <li class="nav-about"><a href="index.php?page=about">About</a></li>
          <li class="nav-about"><a href="Index.php?page=contact">Contact Us</a></li>


        </ul>
      </nav><!-- .nav-menu -->


    </div>
  </header><!-- End Header -->
  <script>
  	$('.nav-<?php echo !isset($_GET['page']) ? 'home': $_GET['page'] ?>').addClass('active');
  </script>