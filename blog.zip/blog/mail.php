<?php

$name = $_POST['name'];

$email = $_POST['email'];

$subject = $_POST['subject'];

$message = $_POST['message'];

$mailheader = "From:".$name."<".$email.">\r\n";

$recipient = "info@sankalpng.com";  //recipient mail

mail($recipient, $subject, $message, $mailheader)
or die("Error!");

echo'

    <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Contact form</title> 
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">
 

	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="container">
		<h1>Thank you for contacting us. We will get back to you as soon as possible!</h1>
		<p>Feel free to contact us and we will get back as soon as we can</p>

		<p class="back">Go back to the <a href="index.php">Home Page</a>.</p>
		
	</div>

</body>
</html>



';


?>