<!--<div class="container">
	<div class="col-md-12">
		<?php echo html_entity_decode($meta['about']) ?>
	</div>
</div>-->





<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Contact form</title> 
	<script
      src="https://kit.fontawesome.com/66aa7c98b3.js"
      crossorigin="anonymous"
    ></script>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">
 

	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<div class="container">
		<br><br><br><br><br><br>
		<h1 >Contact Us</h1>
		<p>Feel free to contact us and we will get back as soon as we can</p>
		<form action="mail.php" method="POST">
			<label for="name">Name:</label>
			<input type="text" name="name" id="name" required>
			<label for="email">Email:</label>
			<input type="email" name="email" id="email" required>
			<label for="subject">subject:</label>
			<input type="type" name="subject" id="subject" required>
			<label for="message">Message</label>
			<textarea name="message" cols="30" rows="10" required></textarea>
			<input type="Submit" value="Send" name="">

		</form>
	</div>
	<div class="footer">
      <div class="heading">
        <div class="details">
          <h4 class="address">Address</h4>
          <p>
            No 9A Farcados Street,Apapa<br/>GRA Lagos Nigeria
          </p>
          <h4 class="mobile">Mobile</h4>
          <p><a href="#">+234 12910915</a></p>
          <h4 class="mail">Email</h4>
          <p><a href="#">Info@sankalpng.com</a></p>
          <p>@2023 All rights reserved by Sankalpng</p>
        </div>
      </div>
      
    </div>
</body>
</html>